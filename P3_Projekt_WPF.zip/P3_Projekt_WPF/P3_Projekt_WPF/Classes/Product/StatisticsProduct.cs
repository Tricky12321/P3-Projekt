﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P3_Projekt_WPF.Classes
{
    public class StatisticsProduct
    {
        public int Amount;
        public decimal Revenue;
    }
}
