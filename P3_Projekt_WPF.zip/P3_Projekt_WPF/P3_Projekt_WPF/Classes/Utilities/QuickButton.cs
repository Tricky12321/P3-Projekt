﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Collections.Concurrent;
using System.Collections;
using System.ComponentModel;
using System.Configuration;

namespace P3_Projekt_WPF.Classes.Utilities
{
    [SettingsSerializeAs(SettingsSerializeAs.Xml)]

    public class QuickButton
    {
        public FastButton ButtonToClick;

    }
}
