﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P3_Projekt_WPF.Classes.Utilities
{
    public enum PaymentMethod_Enum
    { None, Cash, Card, MobilePay }
}
