﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P3_Projekt_WPF.Classes.Utilities
{
    class TempListItem
    {
        public string Description { get; set; }
        public decimal Price { get; set; }
    }
}
