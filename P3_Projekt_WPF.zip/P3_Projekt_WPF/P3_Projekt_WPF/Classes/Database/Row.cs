﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P3_Projekt_WPF.Classes.Database
{
    public class Row
    {
        public List<string> Colums = new List<string>();
        public List<string> Values = new List<string>();
    }
}
